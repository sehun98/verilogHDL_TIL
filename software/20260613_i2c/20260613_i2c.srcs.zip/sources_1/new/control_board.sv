`timescale 1ns / 1ps

module control_board(

    );
endmodule
